<?php

 //   $connection=mysqli_connect('localhost:8080','root','','ckeditor')
  //  or die("databse is not connected".mysqli_connect_error());
  $connection = mysqli_connect("localhost","root","","ckeditor");
 
  // Check connection
  if (mysqli_connect_errno())
    {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
//write query
$sql='SELECT id,content, id FROM content' ;
//make query and result
$result=mysqli_query($connection,$sql);
//fetch result
$articles =mysqli_fetch_all($result, MYSQLI_ASSOC);
//free result
//mysqli_free_result($result);
//close connection
//mysqli_close($articles);

//print_r($articles);
 ?>
<!DOCTYPE html>
<html>
  <h4>ARTICLES!</h4>
  <style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 40%;
  border-radius: 5px;
  background-color:powderblue;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

img {
  border-radius: 5px 5px 0 0;
}

.container {
  padding: 2px 16px;
}
</style>

<h2>Round Card</h2>






  <div  >
  <div >
<?php foreach((array)$articles as $article){ ?>
      <div class="col s6 md3">
          <div class="card z-depth-0">
            <h2><?php echo htmlspecialchars($article['id']); ?></h2>
            <div><?php echo htmlspecialchars($article['content']); ?> </div>
          
            <a href='edit.php?i=<?php echo htmlspecialchars($article['id']);?> &c=<?php echo htmlspecialchars($article['content']); ?>'>edit</a>
      </div>

<?php } ?>
  </div>
  </div>
</html>
