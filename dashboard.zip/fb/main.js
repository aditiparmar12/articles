

     // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyBJPS20n3FtVNBOmMvSWb1tGzCv6VqrwTA",
    authDomain: "articles-ba233.firebaseapp.com",
    databaseURL: "https://articles-ba233.firebaseio.com",
    projectId: "articles-ba233",
    storageBucket: "articles-ba233.appspot.com",
    messagingSenderId: "753055126379",
    appId: "1:753055126379:web:f5c56a58c4be5d9cc1f22e",
    measurementId: "G-LPLJMSNRG7"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
// Reference messages collection
var messagesRef = firebase.database().ref('users');

// Listen for form submit
document.getElementById('contactForm').addEventListener('submit', submitForm);

// Submit form
function submitForm(e){
  e.preventDefault();

  // Get values
  var name = getInputVal('name');
  var company = getInputVal('company');
  var email = getInputVal('email');
  var phone = getInputVal('phone');
  var message = getInputVal('message');

  // Save message
  saveMessage(name, company, email, phone, message);

  // Show alert
  document.querySelector('.alert').style.display = 'block';

  // Hide alert after 3 seconds
  setTimeout(function(){
    document.querySelector('.alert').style.display = 'none';
  },3000);

  // Clear form
  document.getElementById('contactForm').reset();
}

// Function to get get form values
function getInputVal(id){
  return document.getElementById(id).value;
}

// Save message to firebase
function saveMessage(name, company, email, phone, message){
  var newMessageRef = messagesRef.push();
  newMessageRef.set({
    name: name,
    company:company,
    email:email,
    phone:phone,
    message:message
  });
}