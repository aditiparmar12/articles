<?php
 $connection = mysqli_connect("localhost","root","","ckeditor");
 
 // Check connection
 if (mysqli_connect_errno())
   {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }
   
 $id=$_GET['i'];
 $getquery = mysqli_query($connection, "SELECT * from `content` WHERE id='$id'");
 while($row = mysqli_fetch_array($getquery)){
        $idd = $row['id'];
        $con = $row['content'];
 }


?>
<html>
    <head>
        <meta charset="utf-8">
         
    </head>
    <body>
        <div class="container" style="width:800px;   display: block; margin-left: auto;margin-right: auto;">
	
        <form action="" method="post" entype="multipart/form-data">

    	    <input name="con" value="<?php echo $idd; ?>" readonly/><br><br>
            <textarea class="ckeditor" name="editor" ><?php echo $con; ?></textarea>
            <br><br><br>


            <input type="submit" id="button" name="submit" value="update">

        </form>
	
        </div>
        <script src="ckeditor/ckeditor.js">

        </script>
        <script>
            CKEDITOR.replace('editor');
        </script>
    </body>
</html>


<?php
 

if (isset($_POST['submit']))
 {
 

    $editor=$_POST['editor'];
   $query="UPDATE `content` SET `content`='$editor' WHERE id='$id'" ;
  $data=mysqli_query($connection,$query);
    if($data)
    {
    echo" updated";
    
$t =  $id."-".time();
$data_file=fopen("$t.html","w");
//  $fd=fopen("styles.css","w");
//$id[$i] = $row['id'];
fwrite($data_file,"<html>");
fwrite($data_file,"<head><link rel=\"stylesheet\" href=\"styles.css\">");
//  fwrite($data_file,"<link rel=\"stylesheet\" href=\"styles.css\">");
// fwrite($data_file,"</head>");  
// $content1[$i] = $row['content';
//  fwrite($data_file,"</html>");
$text_to_write = $editor;
fwrite($data_file,$text_to_write);
fclose($data_file);
    }else{
        echo  "not updated";
    }

}
?>